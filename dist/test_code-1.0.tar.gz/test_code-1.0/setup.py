from setuptools import setup

setup(
    name="test_code",
    version='1.0',
    description='test',
    author='y-yana',
    url='https://github.com/y-yana/unipa-scraping-lib',
)
