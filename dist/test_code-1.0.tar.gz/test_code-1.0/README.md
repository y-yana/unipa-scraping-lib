# Unipa Scraping Library
## install
```
$ python3 -m venv unipa-lib-env
```
```
$ source ./unipa-lib-env/bin/activate
```
```
unipa-lib-env $ pip install -r requirements.txt
```
```
unipa-lib-env $ deactivate
```
