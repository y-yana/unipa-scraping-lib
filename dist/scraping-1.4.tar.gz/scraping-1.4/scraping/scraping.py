def call():
    print("scraping")
