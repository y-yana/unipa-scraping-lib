def call():
    print("Hello World")
