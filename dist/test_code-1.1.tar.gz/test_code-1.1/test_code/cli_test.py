def execute():
    print('コマンドが実行されました！')
